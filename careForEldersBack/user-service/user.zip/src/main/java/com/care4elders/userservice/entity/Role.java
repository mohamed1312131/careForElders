package com.care4elders.userservice.entity;

public enum Role {
    NURSE,USER,ADMINISTRATOR,DOCTOR
}
