package com.care4elders.paramedicalcare;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ParamedicalCareApplicationTests {

    @Test
    void contextLoads() {
    }

}
