package com.care4elders.paramedicalcare;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ParamedicalCareApplication {

    public static void main(String[] args) {
        SpringApplication.run(ParamedicalCareApplication.class, args);
    }

}
