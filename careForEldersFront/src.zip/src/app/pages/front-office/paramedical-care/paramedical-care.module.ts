import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ParamedicalCareRoutingModule } from './paramedical-care-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    ParamedicalCareRoutingModule
  ]
})
export class ParamedicalCareModule { }
