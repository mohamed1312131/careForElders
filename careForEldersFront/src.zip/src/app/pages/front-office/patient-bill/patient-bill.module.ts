import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PatientBillRoutingModule } from './patient-bill-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    PatientBillRoutingModule
  ]
})
export class PatientBillModule { }
