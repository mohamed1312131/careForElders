import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PlanAndExerciseRoutingModule } from './plan-and-exercise-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    PlanAndExerciseRoutingModule
  ]
})
export class PlanAndExerciseModule { }
