import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { BlogForumRoutingModule } from './blog-forum-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    BlogForumRoutingModule
  ]
})
export class BlogForumModule { }
