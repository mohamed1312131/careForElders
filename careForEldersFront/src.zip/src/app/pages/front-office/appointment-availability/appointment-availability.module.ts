import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AppointmentAvailabilityRoutingModule } from './appointment-availability-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    AppointmentAvailabilityRoutingModule
  ]
})
export class AppointmentAvailabilityModule { }
