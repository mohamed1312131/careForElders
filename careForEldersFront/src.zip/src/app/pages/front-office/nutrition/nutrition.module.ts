import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { NutritionRoutingModule } from './nutrition-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    NutritionRoutingModule
  ]
})
export class NutritionModule { }
