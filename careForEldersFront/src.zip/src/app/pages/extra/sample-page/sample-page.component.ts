import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sample-page',
  templateUrl: './sample-page.component.html'
})
export class AppSamplePageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
